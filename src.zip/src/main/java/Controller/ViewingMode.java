/*
  Author: Joel Eriksson Sinclair
  Id: ai7892
  Study program: Sys 21h
*/

package Controller;

public enum ViewingMode {
    PRODUCTS,
    CART,
    ORDERHISTORY,
}
