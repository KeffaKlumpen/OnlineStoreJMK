/*
  Author: Joel Eriksson Sinclair
  Id: ai7892
  Study program: Sys 21h
*/

package Controller;

public class Main {
    public static void main(String[] args) {
        Controller controller = new Controller();
    }
}
